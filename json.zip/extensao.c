#include <stdlib.h>
#include <string.h>
#include "extensao.h"

// Funções usadas no programa 
int analisa(char *buffer, int *elementos, int *i);
int objects(char *buffer, int *elementos, int *i);
int arrays(char *buffer, int *elementos, int *i);
int pairs(char *buffer, int *elementos, int *i);
int strings(char *buffer, int *elementos, int *i);
int numbers(char *buffer, int *elementos, int *i);
int trues(char *buffer, int *elementos, int *i);
int falses(char *buffer, int *elementos, int *i);
int nulls(char *buffer, int *elementos, int *i);	

// Função que retira espaco
char* retiraEspaco(char* string){
  char *novo = malloc(sizeof(char) * strlen(string));
  int i, j = 0;

  for(i = 0; i <= strlen(string); i++){
  	// Se houver espaço entre número ele deixa passar para dar erro
    if(string[i] != ' ' || (i > 0 && string[i-1] >= 48 && string[i-1] <= 57)){
    	novo[j] = string[i];
      	j++;
    }
  }

  return novo;
}

// Analisa a string chamando as outras funções, se não for nenhuma delas então deu erro
int analisa(char *buffer, int *elementos, int *i){
  if(objects(buffer, elementos, i)){ 
  	return 1;
  }else if(arrays(buffer, elementos, i)){
  	return 1;
  }else if(strings(buffer, elementos, i)){
  	return 1;
  }else if(numbers(buffer, elementos, i)){ 
  	return 1;
  }else if(trues(buffer, elementos, i)){ 
  	return 1;
  }else if(falses(buffer, elementos, i)){ 
  	return 1;
  }else if(nulls(buffer, elementos, i)){
  	return 1;
  }else{
    return 0;
  }
}

int objects(char *buffer, int *elementos, int *i){
	// Confere se é objeto
	if(buffer[*i] != '{'){
		return 0;
	}

	// Vai para o próximo caractere
	(*i)++;

	// Confere se o pair dá certo
	if(pairs(buffer, elementos, i)){
		// Se passou em tudo incrementa objeto e vai para próximo caractere
		elementos[OBJECTS]++;
		(*i)++;

		return 1;	
	}else{
		return 0;
	}
}

int arrays(char *buffer, int *elementos, int *i){
	// Confere se é um array
	if(buffer[*i] != '['){
		return 0;
	}

	// Vai para próximo caractere
	(*i)++;

	// Enquanto o array não acabar ou chegar no final da string, vai lendo 
	while(buffer[*i] != ']' && buffer[*i] != '\0'){
    	if(buffer[*i] != ','){
    		// Se não for  ',' ele analisa o dado
     		if(!analisa(buffer, elementos, i)){
    			return 0;
      		}
      		// Impede de pular dois caracteres
      		(*i)--;
		}

		// Vai para práximo caractere
    	(*i)++;
  	}

  	// Se o array não acabar em ] retorna erro
  	if(buffer[*i] != ']'){
    	return 0;
  	}else{
  		// Se não, incrementa arrays e vai para pŕoximo caractere
  		(*i)++;
  		elementos[ARRAYS]++;
  		return 1;
  	}
}

int pairs(char *buffer, int *elementos, int *i){
	// Confere se começa com uma string, se não retorna erro
	if(!strings(buffer, elementos, i)){
		return 0;
	}

	// Verifica se após a string existe ':', se não tiver retorna erro
	if(buffer[*i] != ':'){
    	return 0;
  	}

  	// Vai para próximo caractere
  	(*i)++;

  	// Como o próximo caractere é um value, analisa para ver o que ele é
  	if(analisa(buffer, elementos, i)){
  		// Se o value é válido, incrementa pairs
  		elementos[PAIRS]++;

  		// Verifica se acabou o objeto
  		if(buffer[*i] == '}'){
    		return 1;
    	}

    	// Se tiver ',' quer dizer que tem mais pairs
	    if(buffer[*i] == ','){
	    	// Vai para próximo caractere e chama a funcao pairs de novo para analisa o novo pair
	    	(*i)++;
	    	return pairs(buffer, elementos, i);
	    }
  	}else{
  		return 0;
  	}

}

int strings(char *buffer, int *elementos, int *i){
	// Ve se começa com aspas
	if(buffer[*i] != '"'){
		return 0;
	}

	// Se houver três aspas seguidas retorna erro
	if(buffer[*i] == '"' && buffer[(*i)+1] == '"' && buffer[(*i)+2] == '"'){
    	return 0;
  	}	

  	// Vai para próximo caractere
  	(*i)++;

  	// Enquanto a string não acabar vai lendo
	while(buffer[*i] != '"'){
		// Se encontrar barra, confere se não há nenhum caractere de controle após ela
		if(buffer[*i] == '\\'){
			if(buffer[(*i)+1] == '"' || buffer[(*i)+1] == '\\' || buffer[(*i)+1] == '/' || buffer[(*i)+1] == 'b' || buffer[(*i)+1] == 'f' || buffer[(*i)+1] == 'n' || buffer[(*i)+1] == 'r' || buffer[(*i)+1] == 'u'){
				return 0;
			}
		}
		// Vai para próximo caractere
		(*i)++;
	}

	// Se a string acabar em aspas está certo
	if(buffer[*i] == '"'){
		// Incrementa strings e vai para próximo caractere
		(*i)++;
		elementos[STRINGS]++;
		return 1;
	}else{
		return 0;	
	}
}

int numbers(char *buffer, int *elementos, int *i){
	// Pula sinal
	if(buffer[*i] == '+' || buffer[*i] == '-'){
		(*i)++;
	}

	// Necessariamente precisa ter número depois 
	if(buffer[*i] < 48 || buffer[*i] > 57){
		return 0;
	}  

	// Percorre os números
	while(buffer[*i] >= 48 && buffer[*i] <= 57){
		(*i)++;	
	}	

	// Se tiver vírgula, verica se está bem formatada
	if(buffer[*i] == '.'){
		// Vai para próximo caractere
		(*i)++;

		// Se não tiver número depois está errado
		if(buffer[*i] < 48 || buffer[*i] > 57){
			return 0;
		}

		// Percorre números
		while(buffer[*i] >= 48 && buffer[*i] <= 57){
			(*i)++;	
		}
	}

	// Confere se houve espaço entre número
	if(buffer[*i] == ' '){
		return 0;
	}

	// Verifica se o exponencial esta bem formatado
	if(buffer[*i] == 'e' || buffer[*i] == 'E'){
		// Vai para próximo caractere
		(*i)++;

		// Pula sinal
		if(buffer[*i] == '+' || buffer[*i] == '-'){
			(*i)++;
		}

		// Se não tiver número depois está errado
		if(buffer[*i] < 48 || buffer[*i] > 57){
			return 0;
		} 

		// Percorre númeross
		while(buffer[*i] >= 48 && buffer[*i] <= 57){
			(*i)++;	
		}
	}

	// Confere se houve espaço entre número
	if(buffer[*i] == ' '){
		return 0;
	}

	// Se passou por tudo, aumenta numbers
	elementos[NUMBERS]++;

	return 1;
}

int trues(char *buffer, int *elementos, int *i){
	// Confere se está escrito true
	if(buffer[*i] == 't' && buffer[*i+1] == 'r' && buffer[*i+2] == 'u' && buffer[*i+3] == 'e') {
		// Se tiver, pula a palavra
		(*i)+=4;

		// Verifica se o true é válido
		if(buffer[*i] != ',' && buffer[*i] != '}' && buffer[*i] != ']'){
			return 0;
		}else{
			// Se for incrementa trues
			elementos[TRUES]++;
			return 1;
		}
	}else{
		return 0;
	}
}

int falses(char *buffer, int *elementos, int *i){
	// Confere se está escrito false
	if(buffer[*i] == 'f' && buffer[*i+1] == 'a' && buffer[*i+2] == 'l' && buffer[*i+3] == 's' && buffer[*i+4] == 'e'){
		// Se tiver, pula a palavra
		(*i)+=5;

		// Verifica se o false é válido
		if(buffer[*i] != ',' && buffer[*i] != '}' && buffer[*i] != ']'){
			return 0;
		}else{
			// Se for incrementa falses
			elementos[FALSES]++;
			return 1;
		}
	}else{
		return 0;
	}
}

int nulls(char *buffer, int *elementos, int *i){
	// Confere se está escrito null
	if(buffer[*i] == 'n' && buffer[*i+1] == 'u' && buffer[*i+2] == 'l' && buffer[*i+3] == 'l') {
		// Se tiver, pula a palavra
		(*i)+=4;

		// Verifica se o null é válido
		if(buffer[*i] != ',' && buffer[*i] != '}' && buffer[*i] != ']'){
			return 0;
		}else{
			// Se for incrementa nulls
			elementos[NULLS]++;
			return 1;
		}
	}else{
		return 0;
	}	
}