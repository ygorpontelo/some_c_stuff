#include <stdio.h>
#include <stdlib.h>
#include "extensao.h"

int main(int argc, char const *argv[]){
	int *elementos, continua = 1, posicao, linha=1;
	char *buffer, *aux;
	size_t bufsize = 32;
    size_t characters;

    // Aloca vetor de contagem de elementos e o buffer
    elementos = (int *) calloc(8, sizeof(int));
    buffer = (char *) malloc(bufsize * sizeof(char));
    if(buffer == NULL || elementos == NULL){
        perror("Erro ao alocar");
        exit(0);
    }

    // Pega linha de entrada e número de caracteres lidos
	characters = getline(&buffer, &bufsize, stdin);

	// Coloca /0 na string 
	if(buffer[characters-1] == '\n'){
      	buffer[characters-1] = '\0';
    }else{
      	buffer[characters] = '\0';
    }

    // Continua até EOF ou erro
	while(characters != -1 && continua){
		// Define posição inicial como 0
		posicao = 0;

		// Tira os espacos da string para evitar erros
		aux = buffer;
		buffer = retiraEspaco(buffer);
		free(aux);

		// Inicia análise e guarda resultado
		continua = analisa(buffer, elementos, &posicao);

		// Se não houve erro, continua lendo
		if(continua){
			// Lê novamente
			free(buffer);
			buffer = (char *) malloc(bufsize * sizeof(char));
			characters = getline(&buffer, &bufsize, stdin);
			if(buffer[characters-1] == '\n'){
		      	buffer[characters-1] = '\0';
		    }else{
		    	buffer[characters] = '\0';
		    }

		    // Incrementa linha
			linha++;
		}
	}

	// Se houve erro exibe a linha de erro
	if(continua == 0){
		printf("Error line %d\n", linha);
	}
	
	// Exibe os valores lidos
	printf("Number of Objects: %d\n", elementos[OBJECTS]);
	printf("Number of Arrays: %d\n", elementos[ARRAYS]);
	printf("Number of Pairs: %d\n", elementos[PAIRS]);
	printf("Number of Strings: %d\n", elementos[STRINGS]);
	printf("Number of Numbers: %d\n", elementos[NUMBERS]);
	printf("Number of Trues: %d\n", elementos[TRUES]);
	printf("Number of Falses: %d\n", elementos[FALSES]);
	printf("Number of Nulls: %d\n", elementos[NULLS]);

	// Libera memória
	free(elementos);
	free(buffer);

	return 0;
}