// Constantes usadas para incrementar vetor
#define OBJECTS 0
#define ARRAYS 1
#define PAIRS 2
#define STRINGS 3
#define NUMBERS 4
#define TRUES 5
#define FALSES 6
#define NULLS 7

// Funções exportadas
int analisa(char *buffer, int *elementos, int *i);
char* retiraEspaco(char* string);