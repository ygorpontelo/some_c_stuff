#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include "grafo.h"

// Preenche o grafo com o peso da aresta
void preecheGrafoPeso(Grafo *g, int arestas){
    int i;
    for(i = 0; i < arestas; i++){
        int x,y,peso;
        scanf("%d %d %d", &x, &y, &peso);
        g->arestas[x][y].destino = y;
        g->arestas[x][y].peso = peso;
        if(g->tipo == 'G'){
            g->arestas[y][x].destino = x;
            g->arestas[y][x].peso = peso;
        }
    }
}

// Preenche o grafo
void preecheGrafo(Grafo *g, int arestas){
    int i;
    for(i = 0; i < arestas; i++){
        int x,y;
        scanf("%d %d", &x, &y);
        g->arestas[x][y].destino = y;
        if(g->tipo == 'G'){
            g->arestas[y][x].destino = x;
        }
    }
}

// Reseta vertices marcados como visitados
void limpaVisitados(Grafo *g){
    int i;
    for(i = 0; i < g->qtdVertices; i++){
        g->vertices[i].visitou = 0;
    }
}

// Aloca o grafo e preenche o mesmo
Grafo* criaGrafo(int vertices, int arestas, char tipo){
    // Aloca o grafo
    Grafo *g = (Grafo*) malloc(sizeof(Grafo));
    
    g->qtdVertices = vertices;
    g->tipo = tipo;
    g->vertices = (Vertice*) malloc(vertices * sizeof(Vertice));
    g->arestas = (Aresta**) malloc(vertices * sizeof(Aresta));

    // Seta visitados para 0
    limpaVisitados(g);

    int i;
    for(i = 0; i < vertices; i++){
        g->arestas[i] = (Aresta*) malloc(vertices * sizeof(Aresta));

        int j;
        for(j=0; j<vertices; j++){
            g->arestas[i][j].destino = -1;
            g->arestas[i][j].peso = -1;
        }
    }

    //preecheGrafoPeso(g, arestas);
    preecheGrafoPeso(g, arestas);

    return g; // Retorna para uso
}

// Exibe os valores do grafo
void exibeGrafo(Grafo* g){
    int i, j;
    // Percorre toda a matriz
    for(i=0; i < g->qtdVertices; i++){
        for(j=0; j < g->qtdVertices; j++){
            // Verifica se a aresta existe
            if(g->arestas[i][j].peso > -1){
                printf("%d ", g->arestas[i][j].peso);
            }else{
                printf(". ");
            }
        }
        printf("\n");
    }
}

// Exibe grafo transposto
void exibeGrafoTransposto(Grafo* g){
    // Checa se for dígrafo
    if(g->tipo == 'D'){
        int i, j;
        for(i=0; i < g->qtdVertices; i++){
            for(j=0; j < g->qtdVertices; j++){
                // Troca linha por coluna
                if(g->arestas[j][i].peso > -1){
                    printf("%d ", g->arestas[j][i].peso);
                }else{
                    printf(". ");
                }
            }
            printf("\n");
        }
    }
}

// Imprime vértices adjacentes ao vertice dado
void imprimeVerticeAdj(Grafo *g, int vertice){
    int i;
    for(i=0; i < g->qtdVertices; i++){
        if(g->arestas[vertice][i].peso > -1){
            printf("%d ", i);
        }
    }
    printf("\n");
}

// Adiciona aresta
void adicionaAresta(Grafo *g, int vertice1, int vertice2, int peso){
    // Checava se a aresta não existia
    //if(g->arestas[vertice1][vertice2].peso < 0){
        g->arestas[vertice1][vertice2].destino = vertice2;
        g->arestas[vertice1][vertice2].peso = peso;
        // Se for não for direcionado, adiciona em ambos caminhos
        if(g->tipo == 'G'){
            g->arestas[vertice2][vertice1].destino = vertice1;
            g->arestas[vertice2][vertice1].peso = peso;
        }
    //}
}

// Remove aresta
void removeAresta(Grafo *g, int vertice1, int vertice2){
    // Checava se existia a aresta
    //if(g->arestas[vertice1][vertice2].peso > -1){
        g->arestas[vertice1][vertice2].destino = -1;
        g->arestas[vertice1][vertice2].peso = -1;
        // Se não for direcionado, remove de ambos os caminhos
        if(g->tipo == 'G'){
            g->arestas[vertice2][vertice1].destino = -1;
            g->arestas[vertice2][vertice1].peso = -1;
        }
    //}
}

// Acha menor aresta
void menorAresta(Grafo *g){
    int i, j, iMenor = MAIOR, jMenor = MAIOR, pesoMenor = MAIOR; 
    for(i=0; i < g->qtdVertices; i++){
        for(j=0; j < g->qtdVertices; j++){
            // Acha o menor
            if(g->arestas[i][j].peso < pesoMenor && g->arestas[i][j].peso > -1){
                iMenor = i;
                jMenor = j;
                pesoMenor = g->arestas[i][j].peso;
            }
        }
    }

    printf("%d %d\n", iMenor, jMenor);
}

// Libera memória
void liberaMemoria(Grafo* g){
    free(g->vertices);
    int i;
    for(i=0; i< g->qtdVertices; i++){
        g->arestas[i];
    }
    free(g->arestas);
}

// Função que faz a busca dfs recursiva
void dfsProcura(Grafo *g, Pilha *p, int verticeComeco, int verticeFim){
    // Insere primeiro valor na pilha
    inserirPilha(p, verticeComeco);

    // Marca que visitou o vertice
    g->vertices[verticeComeco].visitou = 1;
    
    // Faz recursao nos vertices enquanto nao for o alvo 
    if(verticeComeco != verticeFim){
        int i;
        for(i = 0; i < g->qtdVertices; i++){
            // Verifica quais vertices tem caminho e não foram visitados
            if(g->vertices[i].visitou == 0 && g->arestas[verticeComeco][i].destino > -1){
                // Chama recurssao para o vertice
                dfsProcura(g, p, i, verticeFim);
            }
        } 
    }

    //Retira vertice a mais se tiver
    if(p->dados[p->primeiro] != verticeFim){
        removerPilha(p);
    }
}

// Função que faz dfs e muda a pilha
void DFS(Grafo *g, Pilha *p, int verticeComeco, int verticeFim){
    // Faz a DFS
    dfsProcura(g, p, verticeComeco, verticeFim);
    
    // Se não tiver chegado no vertice alvo, limpa a pilha
    if(p->dados[p->primeiro] != verticeFim){
        esvaziaPilha(p);
    }

    // Reseta os visitados para 0
    limpaVisitados(g);
}

// Função que faz a busca dfs recursiva para vertices com caminho
void dfspProcura(Grafo *g, Pilha *p, int verticeComeco){
    // Marca que visitou o vertice
    g->vertices[verticeComeco].visitou = 1;
        
    int i;
    for(i = 0; i < g->qtdVertices; i++){
        // Verifica quais vertices tem caminho e não foram visitados
        if(g->vertices[i].visitou == 0 && g->arestas[verticeComeco][i].destino > -1){
            // Chama recurssao para o vertice
            dfspProcura(g, p, i);
        }
    }  

    // Insere primeiro valor na pilha
    inserirPilha(p, verticeComeco);
}

// Função que faz a busca dfs recursiva para vertices sem caminho
void dfspProcura2(Grafo *g, Pilha *p, int verticeComeco){
    // Marca que visitou o vertice
    g->vertices[verticeComeco].visitou = 1;
        
    int i;
    for(i = 0; i < g->qtdVertices; i++){
        // Verifica quais vertices tem caminho e não foram visitados
        if(g->vertices[i].visitou == 0 && g->arestas[verticeComeco][i].destino == -1){
            // Chama recurssao para o vertice
            dfspProcura(g, p, i);
        }
    }  

    // Insere primeiro valor na pilha
    if(verificaPilha(p, verticeComeco) == 0){
        inserirPilha(p, verticeComeco);
    }
}

// Função que faz dfs e muda a pilha
void DFSP(Grafo *g, Pilha *p, int verticeComeco){
    // Faz a DFS
    dfspProcura(g, p, verticeComeco); 
    dfspProcura2(g, p, verticeComeco);
    
    // Reseta os visitados para 0
    limpaVisitados(g);
}

void bfsProcura(Grafo *g, Pilha *p, int verticeComeco, int verticeFim){
    int predecessor[g->qtdVertices];    // Vetor para guardar antecessores
    int aux[g->qtdVertices];            // Vetor para guardar caminho
    int i, count = 0;                   // Auxiliares
    
    // Preenche vetores criados
    for(i = 0; i < g->qtdVertices; i++){
        predecessor[i] = -1;
        aux[i] = -1;
    }

    // Define inicio como -2 para controle
    predecessor[verticeComeco] = -2;
    
    // Cria fila pra usar na BFS
    Fila *f = criarFila(100);

    // Insere valor inicial na fila
    inserirFila(f, verticeComeco);

    // E marca que visitou o vertice
    g->vertices[verticeComeco].visitou = 1;

    while(!estaVaziaFila(f)){
        // Pega o primeiro valor da fila
        verticeComeco = f->dados[f->primeiro];
        
        // Remove o primeiro valor da fila
        removerFila(f);
        
        // Se tiver no correto sai do loop
        if(verticeComeco == verticeFim){
            break;
        }
        
        for(i = 0; i < g->qtdVertices; i++){
            // Verifica quais vertices tem caminho e não foram visitados
            if(g->arestas[verticeComeco][i].destino > -1 && g->vertices[i].visitou == 0){
                // Insere novos valores na fila
                inserirFila(f, i);
                
                // Marca que visitou o vertice
                g->vertices[i].visitou = 1;
                
                // Guarda Predecessor do vertice
                predecessor[i] = verticeComeco;
            }
        }

        // No fim marca o vertice como visitado
        g->vertices[verticeComeco].visitou = 1;
    }

    // Se chegou no vertice final
    if(verticeComeco == verticeFim){
        // Percorre antecessores
        while(verticeComeco != -2){
            // Adiciona no vetor aux a resp, está invertida!
            aux[count] = verticeComeco;
            
            count++; // Atualiza contador

            // Atualiza antecessor
            verticeComeco = predecessor[verticeComeco];
        }
        
        // Percorre vetor aux para pegar resp
        for(i = g->qtdVertices -1; i >= 0; i--){
            if(aux[i] > -1){
                // Insere valores válidos na pilha de retorno
                inserirPilha(p, aux[i]);
            }
        }
    }

    // Libera memória da fila
    liberaFila(f);
}

void BFS(Grafo *g, Pilha *p, int verticeComeco, int verticeFim){
    // Faz a BFS
    bfsProcura(g, p, verticeComeco, verticeFim);

    // Reseta os visitados para 0
    limpaVisitados(g);
}

// Acha a menor aresta do conjunto de arestas dado
int chaveMinima(int chaves[], int set[], int nVertices){
    // Initialize min value
    int min = INT_MAX, min_index, v;
 
    for (v = 0; v < nVertices; v++){
        if (set[v] == 0 && chaves[v] < min){
            min = chaves[v];
            min_index = v;
        }
    }
    
    return min_index;
}
 
// Funcao para exibir 
int exibePrim(int parent[], int ordem[], Grafo *g){
    int i;
    
    // Passa pela Prim gerada
    for(i = 1; i < g->qtdVertices; i++){
        if(parent[ordem[i]] < ordem[i]){
            printf("(%d,%d) ", parent[ordem[i]], ordem[i]);
        }else{
            printf("(%d,%d) ", ordem[i], parent[ordem[i]]);
        }
    }
    printf("\n");
}
 
// Funcao para construir a Prim e exibir
void primGen(Grafo *g){
    int parent[g->qtdVertices];     // Armazena Prim 
    int chave[g->qtdVertices];      // Valores para pegar o menor peso
    int set[g->qtdVertices];        // Vertices nao inclusos na Prim
    int ordem[g->qtdVertices];
    int i, j, contador = 0;
 
    // Incializa chaves
    for (i = 0; i < g->qtdVertices; i++){
        chave[i] = INT_MAX;
        set[i] = 0;
    }

    // Sempre inclui primeiro vertice
    chave[0] = 0;      // Pega sempre o vertice 0
    parent[0] = -1;    // primeiro no eh sempre a raiz 
 
    // A Prim tera nVertices
    for (i = 0; i < g->qtdVertices; i++){
        // Pega o minimo vertice do set ainda nao incluso
        int min = chaveMinima(chave, set, g->qtdVertices);
        ordem[contador] = min;
        contador++;
        
        // Adiciona vertice no set
        set[min] = 1;

        // Atualiza os vertices
        for (j = 0; j < g->qtdVertices; j++){
            // Verifica se tem caminho, se foi incluso, e atualiza se o peso for menor
            if (g->arestas[min][j].destino > -1 && set[j] == 0 && g->arestas[min][j].peso < chave[j]){
                parent[j] = min;
                chave[j] = g->arestas[min][j].peso;
            }
        }
    }
 
    // Exibe mst
    exibePrim(parent, ordem, g);
}

// Funcao auxiliar do dijkstra, pega vertice com menor peso dos nao visitados
int distMin(int vertices, int D[], int S[]){
    int min = INT_MAX, iMin;

    int i;
    for (i = 0; i < vertices; i++)
        if (S[i] == 0 && D[i] <= min)
            min = D[i], iMin = i;

    return iMin;
}

// Exibe caminho recursivamente, tras pra frente
void exibe(int antecessor[], int vO, int vD, int atual, int peso){
    if(atual == vO){
        printf("%d", vO);
    }else if(antecessor[atual] != -1){
        exibe(antecessor, vO, vD, antecessor[atual], peso);
        printf("%d", atual);
    }

    if(atual != vD){
        printf(" ");
    }else{
        // Peso do caminho
        //if(peso != INT_MAX)
        //    printf(" - Peso: %d\n", peso);
        printf("\n");
    }
}

void dijkstra(Grafo *g, int vO, int vD){
    int i, D[g->qtdVertices], S[g->qtdVertices], antecessor[g->qtdVertices];

    // Inicializa tudo com maior peso possivel
    for (i = 0; i < g->qtdVertices; i++)
        D[i] = INT_MAX, S[i] = 0, antecessor[i] = -1;

    D[vO] = 0; // Dist da origem sempre 0

    // Percorre todos os vertices
    for(i = 0; i < g->qtdVertices-1; i++){
        // Pega vertices com distancia minima ainda n visitado
        int u = distMin(g->qtdVertices, D, S);

        // Marca vertice escolhido como visitado
        S[u] = 1;

        // Atualiza peso do vertice escolhido
        int j;
        for (j = 0; j < g->qtdVertices; j++){
            // Se nao tiver sido visitado, tiver uma aresta e peso total da origem ate j atraves de u for menor que peso atual de D[j]
            if (!S[j] && g->arestas[u][j].destino > -1 && D[u] != INT_MAX && D[u] + g->arestas[u][j].peso < D[j]){
                D[j] = D[u] + g->arestas[u][j].peso;    // Adiciona peso
                antecessor[j] = u;                      // Atualiza antecessores
            }
        }
        
        // Se o vertice escolhido já tiver sido o destino, pode parar o algoritmo
        if(u == vD)
            break;
    }

    // Funcao que exibe caminho
    exibe(antecessor, vO, vD, vD, D[vD]);
}