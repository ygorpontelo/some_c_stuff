#ifndef FILA_H
#define FILA_H

typedef int elemFila;

typedef struct fila {
	int capacidade;
	int *dados;
	int primeiro;
	int ultimo;
	int nItens;

} Fila;

Fila* criarFila(int c);
void inserirFila(Fila *f, elemFila v);
void removerFila(Fila *f);
int estaVaziaFila(Fila *f);
int estaCheiaFila(Fila *f);
void liberaFila(Fila *f);
void exibeFila(Fila *f);

#endif