#ifndef GRAFO_H
#define GRAFO_H

#include <limits.h>
#include "pilha.h"
#include "fila.h"

#define MAIOR INT_MAX  // Define constante para controle 

// Estrutura de dados usada para matriz
typedef struct node {
    int id;
    int grau;
    int visitou;
} Vertice;

typedef struct edge {
    int destino;
    int peso;
} Aresta;

typedef struct graph {
    int qtdVertices;
    char tipo;
    Vertice *vertices;
    Aresta **arestas;
} Grafo;

// Funções Matriz
Grafo* criaGrafo(int vertices, int arestas, char tipo);
void exibeGrafo(Grafo* g);
void exibeGrafoTransposto(Grafo* g);
void imprimeVerticeAdj(Grafo *g, int vertice);
void adicionaAresta(Grafo *g, int vertice1, int vertice2, int peso);
void removeAresta(Grafo *g, int vertice1, int vertice2);
void menorAresta(Grafo *g);
void liberaMemoria(Grafo* g);
void DFS(Grafo *g, Pilha *p, int verticeComeco, int verticeFim);
void BFS(Grafo *g, Pilha *p, int verticeComeco, int verticeFim);
void DFSP(Grafo *g, Pilha *p, int verticeComeco);
void primGen(Grafo *g);
void dijkstra(Grafo *g, int vO, int vD);

#endif