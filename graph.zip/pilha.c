#include <stdio.h>
#include <stdlib.h>
#include "pilha.h"

// Aloca pilha e devolve
Pilha* criarPilha(int c) {
	Pilha *p = (Pilha*) malloc(sizeof(Pilha));
	p->capacidade = c;
	p->dados = (elemPilha*) malloc (p->capacidade * sizeof(elemPilha));
	p->primeiro = -1;
	p->nItens = 0;

	return p;
}

// Se pilha está cheia, retorna para o começo
void inserirPilha(Pilha *p, elemPilha v) {
	if(p->primeiro == p->capacidade-1)
		p->primeiro = -1;

	p->primeiro++;
	p->dados[p->primeiro] = v; // incrementa primeiro e insere
	p->nItens++; // mais um item inserido

}

void removerPilha(Pilha *p) { // pega o item do final da pilha
	if(estaVaziaPilha(p) == 0){
		p->primeiro--;

		if(p->primeiro < 0)
			p->primeiro = 0;

		p->nItens--;  // um item retirado
	}
}

int estaVaziaPilha(Pilha *p) { // retorna verdadeiro se a pilha está vazia
	return (p->nItens == 0);
}

int estaCheiaPilha(Pilha *p) { // retorna verdadeiro se a pilha está cheia
	return (p->nItens == p->capacidade);
}

void esvaziaPilha(Pilha *p){
	while(estaVaziaPilha(p) != 1){
		removerPilha(p);
	}
}

void liberaPilha(Pilha *p){
    free(p->dados); // Libera vetor
    free(p); // Libera pilha
}

// Exibe elementos da pilha
void exibePilha(Pilha *p){
	if(estaVaziaPilha(p) == 0){
		int i;
		for(i = 0; i <= p->primeiro; i++){
			printf("%d ", p->dados[i]);
		}
	}
	printf("\n");
}

// Exibe elementos da pilha
void exibeInversoPilha(Pilha *p){
	if(estaVaziaPilha(p) == 0){
		int i;
		for(i = p->primeiro; i>=0; i--){
			printf("%d ", p->dados[i]);
		}
	}
	printf("\n");
}

int verificaPilha(Pilha *p, elemPilha x){
	int i;
	for(i=0; i<p->nItens; i++){
		if(p->dados[i] == x){
			return 1;
		}
	}	

	return 0;
}