#ifndef PILHA_H
#define PILHA_H

typedef int elemPilha;

typedef struct pilha {
	int capacidade;
	int *dados;
	int primeiro;
	int nItens;

} Pilha;

Pilha* criarPilha(int c);
void inserirPilha(Pilha *p, elemPilha v);
void removerPilha(Pilha *p);
int estaVaziaPilha(Pilha *p);
int estaCheiaPilha(Pilha *p);
void liberaPilha(Pilha *p);
void exibePilha(Pilha *p);
void esvaziaPilha(Pilha *p);
int verificaPilha(Pilha *p, elemPilha x);
void exibeInversoPilha(Pilha *p);

#endif