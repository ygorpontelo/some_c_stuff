#include <stdio.h>
#include <stdlib.h>
#include "fila.h"

// Aloca fila e devolve
Fila* criarFila(int c) {
	Fila *f = (Fila*) malloc(sizeof(Fila));
	f->capacidade = c;
	f->dados = (elemFila*) malloc (f->capacidade * sizeof(elemFila));
	f->primeiro = 0;
	f->ultimo = -1;
	f->nItens = 0;

	return f;
}

// Se fila está cheia, retorna para o começo
void inserirFila(Fila *f, elemFila v) {
	if(f->ultimo == f->capacidade-1)
		f->ultimo = -1;

	f->ultimo++;
	f->dados[f->ultimo] = v; // incrementa ultimo e insere
	f->nItens++; // mais um item inserido

}

void removerFila(Fila *f) { // pega o item do começo da fila
	f->primeiro++;

	if(f->primeiro == f->capacidade)
		f->primeiro = 0;

	f->nItens--;  // um item retirado
}

int estaVaziaFila(Fila *f) { // retorna verdadeiro se a fila está vazia
	return (f->nItens == 0);
}

int estaCheiaFila(Fila *f) { // retorna verdadeiro se a fila está cheia
	return (f->nItens == f->capacidade);
}

void liberaFila(Fila *f){
    free(f->dados);
    free(f);
}

// Exibe elementos da fila
void exibeFila(Fila *f){
	int i;
	for(i = f->primeiro; i <= f->ultimo; i++){
		printf("%d ", f->dados[i]);
	}
	printf("\n");
}