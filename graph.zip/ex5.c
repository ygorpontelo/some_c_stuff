#include <stdio.h>
#include <stdlib.h>
#include "grafo.h"

int main(){
    int v, a, vO, vD;

    scanf("%d %d", &v, &a);

    Grafo *g = criaGrafo(v, a, 'D');

    while(scanf("%d %d", &vO, &vD) != EOF){
        dijkstra(g, vO, vD);
    }

    return 0;
}