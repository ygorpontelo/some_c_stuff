#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include "estruturas.h"

int main(int argc, char const *argv[]){
	elem c[1000];
	elem2 resultado;
	int i, j, continua, continuaT = 1, erro;

	do{

		// Define as structs
		final f;  f.tam = 0;
		operador o;  o.tam = 0;

		// Condições iniciais
		continua = 1; erro = 0; i=0;

		// Le a string
		fgets(c, 1000, stdin); 

		do{
			// Coloca nas pilhas de acordo com a string
			if(c[i] == '+' || c[i] == '-'){
				// Desempilha todos os operadores ou até chegar em '('
				while(o.tam > 0 && o.pilha[o.tam-1] != '('){
					f.pilha[f.tam][0] = o.pilha[o.tam-1];
					f.pilha[f.tam][1] = '\0';
					o.tam--;
					f.tam++;
				}
				// Adiciona operador
				o.pilha[o.tam] = c[i];
				o.tam++; 
			}else if(c[i] == '*' || c[i] == '/'){
				// Desempilha operadores de multiplicação ou divisão
				while(o.pilha[o.tam-1] == '*' || o.pilha[o.tam-1] == '/'){ 
					f.pilha[f.tam][0] = o.pilha[o.tam-1];
					f.pilha[f.tam][1] = '\0';
					o.tam--;
					f.tam++;
				}
				// Adiciona operador
				o.pilha[o.tam] = c[i];
				o.tam++;	
			}else if(c[i] == '('){
				// Adiciona parenteses no operador
				o.pilha[o.tam] = '(';
				o.tam++;
			}else if(c[i] == ')'){
				// Desempilha até achar um '('
				while(o.pilha[o.tam-1] != '('){
					f.pilha[f.tam][0] = o.pilha[o.tam-1];
					f.pilha[f.tam][1] = '\0';
					f.tam++;
					o.tam--;
					if(o.tam == 0){
						// Se desempilhar tudo quer dizer que tem parenteses errado
						erro = 1;
						break;
					}
				}
				o.tam--;
			// Ve se é numero ou ponto
			}else if((c[i] >= 48 && c[i] <= 57) || c[i] == 46){
				j = 0;
				// Enquanto for numero ou ponto adiciona na string
				while((c[i] >= 48 && c[i] <= 57) || c[i] == 46){
					f.pilha[f.tam][j] = c[i];
					j++;
					i++;	
				}
				// Volta um para porque no final ele incrementa
				i--; 
				// Define final de string e incrementa tamanho
				f.pilha[f.tam][j] = '\0';
				f.tam++;
			}else if(c[i] == ',' || c[i] == ';'){
				// Define condições para sair
				continua = 0;
				if(c[i] == ','){
					continuaT = 0;
				}
			}else if(c[i] != 32){
				// Se for algum caractere diferente de espaço ou qualquer um dos acima dá erro
				erro = 1;
			}

			// vai para o pŕoximo caractere
			i++;

		} while(continua);

		// Desempilha tudo no final
		while(o.tam > 0){
			// Se achar parenteses quer dizer que deu errado
			if(o.pilha[o.tam-1] == '('){
				erro = 1;
				break;
			}
			// Vai desempilhando
			f.pilha[f.tam][0] = o.pilha[o.tam-1];
			f.pilha[f.tam][1] = '\0';
			f.tam++;
			o.tam--;
		}

		// Exibe resultado
		if(erro){
			printf("Expressao incorreta\n");
		}else{
			resultado = calcula(f.pilha, f.tam);
			// Confere se houve divisão por zero
			if(resultado == ERRO){
				printf("Expressao incorreta\n");
			}else{
				printf("%.2lf\n", resultado);
			}
		}

	} while(continuaT);

	return 0;
}