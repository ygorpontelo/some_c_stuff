// Define nomes 
typedef char elem;
typedef float elem2;

// Define constante de erro
#define ERRO INT_MIN 

// Usado para expressao formatada
typedef struct f{
	elem pilha[100][10]; 
	int tam;
} final;

// Usado para guardar operadores
typedef struct o{
	elem pilha[100]; 
	int tam;
} operador;

// Usado para calcular
typedef struct c{
	elem2 pilha[100]; 
	int tam;
} calculo;

elem2 calcula(char pilha[][10], int tam);