#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include "estruturas.h"

// Calcula o resultado
elem2 calcula(char pilha[][10], int tam){
	calculo c;
	c.tam = 0;

	int i;
	
	// Adiciona na pilha calculo e vai resolvendo
	for(i=0; i<tam; i++){
		if(!strcmp(pilha[i], "+")){
			c.pilha[c.tam-2] = c.pilha[c.tam-2] + c.pilha[c.tam-1];
			c.tam--;
		}else if(!strcmp(pilha[i], "-")){
			c.pilha[c.tam-2] = c.pilha[c.tam-2] - c.pilha[c.tam-1];
			c.tam--;
		}else if(!strcmp(pilha[i], "*")){
			c.pilha[c.tam-2] = c.pilha[c.tam-2] * c.pilha[c.tam-1];
			c.tam--;
		}else if(!strcmp(pilha[i], "/")){
			// Se o divisor for zero
			if(c.pilha[c.tam-1] == 0){
				return ERRO;
			}
			c.pilha[c.tam-2] = c.pilha[c.tam-2] / c.pilha[c.tam-1];
			c.tam--;
		}else{
			c.pilha[c.tam] = atof(pilha[i]);
			c.tam++;
		}
	}

	return c.pilha[0];
}