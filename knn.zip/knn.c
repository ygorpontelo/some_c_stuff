#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <math.h>

#define ATRIBUTOS 4     // Qtd de atributos da flor
#define TAMBUFFER 1024  // Tamanho do buffer

// Struct usada para a flor
typedef struct flor{
    float vetor[ATRIBUTOS]; // Vetor de atributos
    char classe[15];        // Classe da flor
}Flor;

// Copia os dados da linha para a Flor, ambos passados por referencia
void pega_atributos(Flor *f, char *linha){
    char palavra[10];
    int i = 0, atr = 0, pos = 0;

    // Vai ate chegar na classe
    while(linha[pos] != '"'){
        // Vai ate acabar um atributo
        while(linha[pos] != ','){
            palavra[i++] = linha[pos]; 
            pos++;
        }
        palavra[i] = '\0';                  // Coloca fim na string
        f->vetor[atr++] = atof(palavra);    // Coloca o atributo no vetor da flor, como float
        i = 0;  // Recomeca palavra
        pos++;
    }
    pos++;  // Sai do "
    i = 0;  // Recomeca palavra
    while(linha[pos] != '\n'){  // Vai ate o final da linha
        if(linha[pos] != '"'){  // Nao copia o "
            palavra[i++] = linha[pos];
        }
        pos++;
    }
    palavra[i] = '\0';          // Coloca fim na string
    strcpy(f->classe, palavra); // Copia a classe para a flor
}

// Calcula a distancia euclidiana
float calcula_distancia(float vetor[], float vetor2[]){
    int i;
    float soma = 0.0;
    for(i=0; i<ATRIBUTOS; i++){
        soma += pow(vetor[i] - vetor2[i], 2);  // (ai - bi)^2
    }
    return (sqrt(soma)); // Raiz da soma
}

// Funcao que verifica se o indice ja esta no vetor
int foi_escolhido(int proximos[], int indice, int tam){
    int i;
    for(i=0; i<tam; i++){
        // Verifica se esta no vetor
        if(proximos[i] == indice){
            return 1;
        }
    }
    return 0;
}

// Verifica se a classe ja existe no vetor
int classe_existe(int *proximos, Flor *flores, int tam){
    int i;
    for(i=0; i<tam; i++){
        // Verifica se a classe existe
        if(strcmp(flores[proximos[i]].classe, flores[proximos[tam]].classe) == 0){
            return i;  // Se existir, retorna o indice na qual ela esta
        }
    }
    return -1;  // Senao, retorna flag indicando que nao existe
}

// Acha a classe mais significativa
char* classe_mais_representativa(int *proximos, int k, Flor *flores){
    int i, classes[k], pos = 0, maior = INT_MIN, indice;
    
    // Nao tem nada no comeco
    for(i=0; i<k; i++) 
        classes[i] = 0;

    classes[pos] = 1;  // A primeira classe sempre tem 1  
    for(i=1; i<k; i++){
        int indice = classe_existe(proximos, flores, i);  // Verifica se a classe ja esta no vetor
        if(indice == -1){
            classes[++pos]++;
        }else{
            classes[indice]++;
        }
    }

    // Acha a classe com mais recorrente, ou com menor distancia caso empate
    for(i=0; i<pos+1; i++){
        if(maior < classes[i]){
            maior = classes[i];
            indice = i;
        }
    }

    return flores[proximos[indice]].classe;  // Retorna a classe
}

// Funcao que classifica uma flor
char* classifica(Flor *teste, Flor *flores, int tam, int k){
    int i, j, proximos[k];
    float distancias[tam];  // Vetor das distancias

    // Calcula a distancia de cada flor
    for(i=0; i<tam; i++){
        distancias[i] = calcula_distancia(teste->vetor, flores[i].vetor);
    }

    // Coloca flags para a func foi_escolhido
    for(i=0; i<k; i++)
        proximos[i] = -1;

    // Acha os k mais proximos, sem repeticoes
    for(i=0; i<k; i++){
        float menor = INT_MAX * 1.0;
        int indice;
        for(j=0; j<tam; j++){
            // Verifica se ja foi escolhido e se eh menor
            if(menor > distancias[j] && !foi_escolhido(proximos, j, k)){
                indice = j;
                menor = distancias[j];
            }
        } 
        proximos[i] = indice;  // Coloca o indice escolhido no vetor
    }

    return classe_mais_representativa(proximos, k, flores);
}

int main(int argc, char const *argv[]){ 
    char nome_treino[10], nome_teste[10], buffer[TAMBUFFER];    // Nomes e buffer
    int k, tam_treino = 1, tam_teste = 1, i, acertos = 0;       // Variaveis de controle
    FILE *treino, *teste;                                       // Arquivos com as informacoes
    Flor *flores_treino, *flores_teste;                         // Conjuntos de flores, de treino e teste

    // Pega informações iniciais
    scanf("%s", nome_treino);
    scanf("%s", nome_teste);
    scanf("%d", &k);

    // Pega as flores de treino
    flores_treino = (Flor*) malloc(sizeof(Flor));
    treino = fopen(nome_treino, "r");  // Abre arq de treino
    fgets(buffer, TAMBUFFER, treino);  // Pula a primeira linha
    while(fgets(buffer, TAMBUFFER, treino)){
        Flor f;
        flores_treino = (Flor*) realloc(flores_treino, sizeof(Flor) * tam_treino);
        pega_atributos(&f, buffer);  // Pega as informacoes da linha
        flores_treino[tam_treino-1] = f;  // Coloca a flor no conjunto
        tam_treino++;  // Atualiza tamanho
    }
    tam_treino--; // Ajusta tamanho

    // Verifica validade de k
    if(k > tam_treino){
        printf("k is invalid\n");
        return 0;
    }

    // Pega os casos de teste, faz o mesmo do treino
    flores_teste = (Flor*) malloc(sizeof(Flor));
    teste = fopen(nome_teste, "r");
    fgets(buffer, TAMBUFFER, teste);
    while(fgets(buffer, TAMBUFFER, teste)){
        Flor f;
        flores_teste = (Flor*) realloc(flores_teste, sizeof(Flor) * tam_teste);
        pega_atributos(&f, buffer);  
        flores_teste[tam_teste-1] = f;
        tam_teste++;
    }
    tam_teste--;
    
    // Classifica as flores de acordo com o treino
    char classificacoes[tam_teste][15];
    for(i=0; i<tam_teste; i++){
        strcpy(classificacoes[i], classifica(&flores_teste[i], flores_treino, tam_treino, k));
    }

    // Exibe as classificacoes
    for(i=0; i<tam_teste; i++){
        printf("%s %s\n", classificacoes[i], flores_teste[i].classe);
        if(strcmp(classificacoes[i], flores_teste[i].classe) == 0)
            acertos++;
    }

    // Exibe a porcencentagem de acerto
    float p = (float) acertos/tam_teste;
    printf("%0.4f\n", p);

    // Libera a memoria utilizada
    free(flores_teste);
    free(flores_treino);
    fclose(teste);
    fclose(treino);

    return 0;
}